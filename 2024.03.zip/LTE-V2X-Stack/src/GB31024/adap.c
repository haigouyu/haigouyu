#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "../../include/GB31024/adap.h"
#include "../../include/GB31024/dsmp.h"
#include "../../include/GB31024/dsmp_encode.h"
#include "../../include/pdu_buf.h"
#include "../../include/net_err.h"
#include "../../include/network.h"

ada_pdu_metadata *init_ada_pdu_metadata(uint16_t ethertype)
{
    ada_pdu_metadata *ptr = malloc(sizeof(ada_pdu_metadata));
    if (ptr == NULL)
    {
        net_error(DSMP_ERROR, "unable to allocate memory to create ADA PDU metadata");
        return NULL;
    }
    ptr->dsap = 0xAB;
    ptr->ssap = 0xAB;
    ptr->control = 0x03;
    ptr->oui[0] = 0x00;
    ptr->oui[1] = 0x00;
    ptr->oui[2] = 0x00;
    ptr->ethertype = ethertype;
    return ptr;
}
/* debug function to print each field in ada frame */
void print_ada_pdu_metadata(const ada_pdu_metadata *self)
{
    printf("DSAP      : %X\n", self->dsap);
    printf("SSAP      : %X\n", self->ssap);
    printf("Control   : %x\n", self->control);
    printf("OUI-1     : %x\n", self->oui[0]);
    printf("OUI-2     : %x\n", self->oui[1]);
    printf("OUI-3     : %x\n", self->oui[2]);
    printf("EtherType : %X\n", self->ethertype);
    printf("\nada pdu metadata printing finished.\n");
}

void free_ada_pdu_metadata(ada_pdu_metadata *self)
{
    free(self);
}

void ada_encode(const ada_pdu_metadata *self, dsmp_pdu *pdu, int *err)
{
    *err = 0;
    if (DSMP_ADA_OUI != ((self->oui[0] << 16) | (self->oui[1] << 8) | self->oui[2]))
    {
        *err = DSMP_ENOSUPPORT;
        net_error(DSMP_WARN, "unsupported OUI field given to encode ADA PDU.");
        return;
    }
    if (self->ethertype != DSMP_ADA_ETHERTYPE_IP && self->ethertype != DSMP_ADA_ETHERTYPE_DSMP)
    {
        *err = DSMP_ENOSUPPORT;
        net_error(DSMP_WARN, "unsupported Ethertype field given to encode ADA PDU.");
        return;
    }
    // don't need to get data seperate as we use the pdu_buf to track the memory locations
    // store_uint8_n(pdu, self->len, self->data, err);   /* DSM Data field */
    store_uint16(pdu, self->ethertype, err); /* ethertype field */
    store_uint8_n(pdu, 3, self->oui, err);   /* OUI field */
    store_uint8(pdu, DSMP_ADA_CONTROL, err); /* Control field */
    store_uint8(pdu, DSMP_ADA_SSAP, err);    /* SSAP field */
    store_uint8(pdu, DSMP_ADA_DSAP, err);    /* DSAP field */
}

ada_pdu_metadata *ada_decode(dsmp_pdu *pdu, int *err)
{
    ada_pdu_metadata *ada_metadata = init_ada_pdu_metadata(DSMP_ADA_ETHERTYPE_DSMP);
    if (ada_metadata == NULL)
    {
        // TODO: *err=?
        return NULL;
    }
    *err = 0;
    retrieve_uint8(pdu, &(ada_metadata->dsap), err);
    retrieve_uint8(pdu, &(ada_metadata->ssap), err);
    retrieve_uint8(pdu, &(ada_metadata->control), err);
    retrieve_uint8_n(pdu, 3, ada_metadata->oui, err);
    if (DSMP_ADA_OUI != ((ada_metadata->oui[0] << 16) | (ada_metadata->oui[1] << 8) | ada_metadata->oui[2]))
    {
        *err = DSMP_ENOSUPPORT;
        net_error(DSMP_WARN, "unsupported OUI field found during ADA PDU decoding.");
        return NULL;
    }
    retrieve_uint16(pdu, &(ada_metadata->ethertype), err);
    if (ada_metadata->ethertype != DSMP_ADA_ETHERTYPE_IP && ada_metadata->ethertype != DSMP_ADA_ETHERTYPE_DSMP)
    {
        *err = DSMP_ENOSUPPORT;
        net_error(DSMP_WARN, "unsupported Ethertype field found during ADA PDU decoding.");
        return NULL;
    }
    return ada_metadata;
}

/* TODO: Need to decide the return type. we can input an error pointer and can check its states */
/* TODO: Power is signed integer. check it again */
/* Issued by DSMP layer to request that LSDU to be sent to Multi-Channel operation layer */
void dl_unitdatax_req(dsmp_pdu *pdu, uint8_t *src_addr, uint8_t *dest_addr, uint8_t prority, uint8_t chan_id, enum time_slot timeslot, uint8_t data_rate,
                      uint8_t txpwr_level, uint8_t channel_load, uint64_t wsm_expire_time, int *err)
{
    /* most of parameters coming from DSMP layer. They have checked once. Only new parameters are src_addr, txpwr_level. */
    /* src_addr, dest_addr, prority, channel_Id etc won't use to encode at ADA. But there will be pass to MAC layer functions */
    *err = 0;
    uint16_t ethertype = DSMP_ADA_ETHERTYPE_DSMP; /* default to DSMP */
    ada_pdu_metadata *ada_metadata = init_ada_pdu_metadata(ethertype);
    if (ada_metadata == NULL)
    {
        net_error(DSMP_WARN, "unable to send wsmp_wsm to MAC layer since failed to create ADA metadata");
        *err = DSMP_ENOMEM;
        return;
    }
    ada_encode(ada_metadata, pdu, err);
    if (*err)
    {
        net_error(DSMP_WARN, "unable to send wsmp_wsm to MAC layer since failed to encode ADA frame");
        // return;
    }
    /* TODO: need to send pdu with relavent parameter to multi channel operational layer running in kernel space */
    // To verify wsm whole flow is working, we are configuring 1609.4 as userspace process which only use signal channal(no channel switching).
    // This is only for the testing purpose.
    // ma_unitdatax_req()
    write_tun(pdu);
    free_ada_pdu_metadata(ada_metadata); // put very end
}

// send payload to DSMP layer.
void dl_unitdata_ind(ada_pdu_metadata *ada_metadata, dsmp_pdu *pdu, int *err)
{
    *err = 0;
    if (ada_metadata->ethertype == DSMP_ADA_ETHERTYPE_IP)
    {
        // current tcp/ip is not supported. log a warning msg
        return;
    }
    // TODO: call DSMP layer function to handover the data.
    // Decode wsm
    // DSM-DsmpShortMessage.indication()
}

// receive packets from multi-channel operational layer.
void dl_recv(int *err)
{
    /** TODO:
     * 1. block and listen to receive data.
     * 2. decode and extract each field while validating and payload.
     * 3. take necessary action if a field has corrupted or has wrong data.
     * 4. call DL-UNITDATA.ind method to send payload to DSMP layer.
     */
    *err = 0;
    dsmp_pdu *pdu = create_pdu_buf();
    // TODO: 1. block listening to receive data. update the pdu as necessary
    // to represent a frame received from multi-channel operation layer.
    ada_pdu_metadata *ada_metadata = ada_decode(pdu, err);
    if (*err)
    {
        // log relvent error
        return;
    }
    dl_unitdata_ind(ada_metadata, pdu, err);
}
