
#include "../../include/GB31024/dsmp.h"
#include "../../include/GB31024/dsmp_encode.h"
#include "../../include/GB31024/adap.h"
#include "../../include/net_err.h"
#include "../../include/network.h"

void free_iex(struct dsmp_iex *curs)
{
    if (curs == NULL)
        return;

    if (curs->raw)
    {
        int i = 0;

        for (i = 0; i < curs->raw_count; i++)
        {
            if (curs->raw[i].data)
                free(curs->raw[i].data);
        }

        free(curs->raw);
    }

    free(curs);
}

void free_sii(struct dsmp_sii *curs)
{
    if (curs == NULL)
        return;

    free_iex(curs->iex);
    free(curs);
}

void free_cii(struct dsmp_cii *curs)
{
    if (curs == NULL)
        return;

    free_iex(curs->iex);
    free(curs);
}

void free_wra(struct dsmp_wra *curs)
{
    if (curs == NULL)
        return;

    free_iex(curs->iex);
    free(curs);
}

void free_dsa(struct dsmp_dsa *curs)
{
    if (curs == NULL)
        return;

    free_iex(curs->iex);

    if (curs->sis)
    {
        int i = 0;
        for (i = 0; i < curs->sii_count; i++)
            free_sii(curs->sis[i]);

        free(curs->sis);
    }

    if (curs->cis)
    {
        int i = 0;
        for (i = 0; i < curs->cii_count; i++)
            free_cii(curs->cis[i]);

        free(curs->cis);
    }

    free_wra(curs->wra);
    free(curs);
}

void free_dsm(struct dsmp_dsm *curs)
{
    if (curs == NULL)
        return;

    free_iex(curs->n_iex);
    free_iex(curs->t_iex);

    /* It is important to note that this data field is a serialized byte array, not a struct. */
    /* That is, one should not attempt to put a struct dsmp_dsa into this field. */
    /* Doing so introduces a safety critical error whereby an attacker can craft messages that leave orphaned blocks of memory, denying servce. */
    if (curs->data)
        free(curs->data);

    free(curs);
}

uint32_t p_to_hex(const uint32_t aid, uint8_t *len)
{
    uint32_t conv = 0;

    if (aid >= DSMP_A1_AMIN && aid <= DSMP_A1_AMAX)
    {
        conv = aid;
        *len = 1;
    }
    else if (aid >= DSMP_A2_AMIN && aid <= DSMP_A2_AMAX)
    {
        conv = (aid ^ DSMP_A2_AXOR) + DSMP_A1_MAX + 1;
        *len = 2;
    }
    else if (aid >= DSMP_A3_AMIN && aid <= DSMP_A3_AMAX)
    {
        conv = (aid ^ DSMP_A3_AXOR) + DSMP_A2_MAX + 1;
        *len = 3;
    }
    else if (aid >= DSMP_A4_AMIN && aid <= DSMP_A4_AMAX)
    {
        conv = (aid ^ DSMP_A4_AXOR) + DSMP_A3_MAX + 1;
        *len = 4;
    }
    else
    {
        conv = 0;
        *len = 0;
    }

    return conv;
}

uint32_t hex_to_p(const uint32_t aid, uint8_t *len)
{
    uint32_t conv;

    if (aid <= DSMP_A1_MAX)
    {
        conv = aid;
        *len = 1;
    }
    else if (aid <= DSMP_A2_MAX)
    {
        conv = aid + DSMP_A2_OFF;
        *len = 2;
    }
    else if (aid <= DSMP_A3_MAX)
    {
        conv = aid + DSMP_A3_OFF;
        *len = 3;
    }
    else if (aid <= DSMP_A4_MAX)
    {
        conv = aid + DSMP_A4_OFF;
        *len = 4;
    }
    else
    {
        conv = 0;
        *len = 0;
    }

    return conv;
}

uint8_t p_count(const uint8_t v)
{
    if (v >> 7 == 0b0)
        return 1;
    else if (v >> 6 == 0b10)
        return 2;
    else if (v >> 5 == 0b110)
        return 3;
    else if (v >> 4 == 0b1110)
        return 4;

    return 0;
}

uint8_t c_count(uint8_t c)
{
    if (c >> 7 == 0b0)
        return 1;
    else if (c >> 6 == 0b10)
        return 2;

    return 0;
}

void _g(const uint8_t *buf, size_t *i, uint8_t *v, size_t len, int *err)
{
    if (*err)
    {
        return;
    }
    else if (*i >= len)
    {
        *err = -DSMP_EFAULT;
        return;
    }

    *v = buf[*i];
    (*i)++;
}

void _gs(const uint8_t *buf, size_t *i, int8_t *v, size_t len, int *err)
{
    if (*err)
    {
        return;
    }
    else if (*i >= len)
    {
        *err = -DSMP_EFAULT;
        return;
    }

    *v = (int8_t)buf[*i];
    (*i)++;
}

void _g_n(const uint8_t *buf, size_t *i, size_t n, uint8_t *v, size_t len, int *err)
{
    int j = 0;

    for (j = 0; j < n; j++)
        _g(buf, i, &v[j], len, err);
}

void _g_p(const uint8_t *buf, size_t *i, uint32_t *v, size_t len, int *err)
{
    uint8_t tmp = 0;
    uint8_t p_c = 0;
    uint32_t conv = 0;

    _g(buf, i, &tmp, len, err);
    p_c = p_count(tmp);

    if (p_c == 0)
    {
        *err = -DSMP_EBADMSG;
        return;
    }

    if (p_c == 1)
        conv = tmp;
    else
        conv |= tmp << ((p_c - 1) * 8);

    int j = 0;

    for (j = p_c - 1; j > 0; j--)
    {
        _g(buf, i, &tmp, len, err);

        if (j - 1 == 0)
            conv |= tmp;
        else
            conv |= tmp << ((j - 1) * 8);
    }

    conv = p_to_hex(conv, &p_c);

    if (p_c == 0)
    {
        *err = -DSMP_EBADMSG;
        return;
    }

    *v = conv;
}

void _g_c(const uint8_t *buf, size_t *i, uint16_t *v, size_t len, int *err)
{
    uint8_t c = 0;
    uint8_t tmp = 0;

    _g(buf, i, &c, len, err);

    tmp = c_count(c);

    if (tmp == 0)
    {
        *err = -DSMP_EBADMSG;
        return;
    }

    if (tmp == 1)
    {
        *v = c;
    }
    else
    {
        uint16_t conv = c & 0x3F;

        _g(buf, i, &tmp, len, err);

        conv <<= 8;
        conv |= tmp;

        *v = conv;
    }
}

void _s(uint8_t *buf, size_t *i, const uint8_t v, size_t len, int *err)
{
    if (*err)
    {
        return;
    }
    if (*i >= len)
    {
        *err = DSMP_EPBUF;
        return;
    }

    buf[*i] = v;
    (*i)++;
}

void _s_n(uint8_t *buf, size_t *i, size_t n, const uint8_t *v, size_t len, int *err)
{
    for (int j = 0; j < n; j++)
        _s(buf, i, v[j], len, err);
}

void _s_p(uint8_t *buf, size_t *i, const uint32_t v, size_t len, int *err)
{
    uint8_t p_c = 0;
    uint32_t conv = hex_to_p(v, &p_c);

    if (p_c == 0)
    {
        *err = -DSMP_EBADMSG;
        return;
    }

    int j = 0;

    for (j = p_c; j > 0; j--)
    {
        if (j - 1 == 0)
            _s(buf, i, conv & 0xFF, len, err);
        else
            _s(buf, i, (conv >> ((j - 1) * 8)) & 0xFF, len, err);
    }
}

void _s_c(uint8_t *buf, size_t *i, const uint16_t v, size_t len, int *err)
{
    if (v < 128)
    {
        _s(buf, i, v, len, err);
    }
    else if (v <= DSMP_MAXCOUNT)
    {
        uint16_t conv = v | 0x8000;
        uint8_t cu = conv >> 8;
        uint8_t cl = conv & 0xFF;

        _s(buf, i, cu, len, err);
        _s(buf, i, cl, len, err);
    }
    else
    {
        *err = -DSMP_EBADMSG;
    }
}

struct dsmp_iex *create_n_iex(uint8_t chan_id, uint8_t data_rate, int8_t tx_pow)
{
    struct dsmp_iex *iex = calloc(1, sizeof(struct dsmp_iex));
    if (chan_id >= 0)
    {
        iex->chan = chan_id;
        iex->count++;
        iex->use[DSMP_EID_CHANNEL_NUMBER_80211] = 1;
    };
    if (data_rate > 1)
    {
        iex->data_rate = data_rate;
        iex->count++;
        iex->use[DSMP_EID_DATA_RATE_80211] = 1;
    };
    if (tx_pow != 0)
    {
        iex->tx_pow = tx_pow;
        iex->count++;
        iex->use[DSMP_EID_TX_POWER_USED_80211] = 1;
    };
    return iex;
};

// TODO: log errors, warns etc, how to return error.
struct dsmp_dsm *create_dsmp_metadata(uint8_t subtype, uint8_t tpid, uint8_t info_elem_indicator, uint8_t chan_id, uint8_t data_rate,
                                      int8_t tx_pow, uint32_t aid, uint16_t len, uint8_t *data)
{
    struct dsmp_dsm *dsm = calloc(1, sizeof(struct dsmp_dsm));

    dsm->subtype = subtype;
    dsm->version = DSMP_VERSION;
    dsm->tpid = tpid; // T-Header Extension field(tpid), only support for tpid=0.

    // N-header option indicator can be 0,1. We always set to one.
    if (info_elem_indicator == 1)
    {
        dsm->use_n_iex = 1;
        dsm->n_iex = create_n_iex(chan_id, data_rate, tx_pow);
    }
    else
    {
        dsm->use_n_iex = 0;
    }
    /**
     * dsm->tpid = 2,3,4,5 are not needed support. No DSMP Information Elements are specified for tpid=1.
     * Therefore tpid=1 case will be neglected.
     */
    if (dsm->tpid == 0)
    {
        dsm->use_t_iex = 0;
        dsm->aid = aid;
    }
    dsm->len = len;
    dsm->data = data;
    return dsm;
}

enum confirm_result_code dsm_dsmpshortmsg_req(uint8_t chan_id, enum time_slot timeslot, uint8_t data_rate, int8_t tx_power, uint8_t channel_load,
                                              uint8_t info_elem_indicator, uint8_t prority, uint64_t dsm_expire_time, uint16_t len, uint8_t *data, uint8_t *peer_mac_addr, uint32_t aid)
{
    uint8_t subtype = 0, tpid = 0; // currently only need to support for TPID=0
    struct dsmp_dsm *dsm_metadata = create_dsmp_metadata(subtype, tpid, info_elem_indicator, chan_id, data_rate, tx_power, aid, len, data);
    int err[1];
    dsmp_pdu *pdu = create_pdu_buf();
    // DSMP Header + DSM data <= DSM Max Length : this check is done within the dsm_encoding
    dsmp_dsm_encode(dsm_metadata, pdu, err, DSMP_STRICT);
    if (*err)
    {
        net_error(DSMP_WARN, "failed to encode dsm with err code");
        return rejected_unspecified;
    }
    // TODO: Resolve this logic
    // DSM data to the LLC sublayer
    char *device = get_network_device();
    uint8_t *src_macaddr = get_mac_addr(device);

    // uint8_t *src_macaddr = "1a:ff:ff:89:21:ca";
    uint8_t tx_pow_level = 14; // TODO: need to map to correct value (tx_power --> tx_pow_level)
    dl_unitdatax_req(pdu, src_macaddr, peer_mac_addr, prority, chan_id, timeslot, data_rate, tx_pow_level, channel_load, dsm_expire_time, err);
    // free_dsm(dsm_metadata);
    return accepted;
}

/**
 * When to use
 * 1. In DSA monitoring, once DSMP layer recieved a DSA it will indicate that to WME via this primitive.
 * 2.
 */
void dsm_dsmpshortmsg_ind(uint8_t version, uint8_t channel_number, uint8_t data_rate, int8_t tx_power,
                          uint8_t channel_load, uint8_t prority, uint16_t len, uint8_t *peer_mac_addr, uint32_t aid, dsmp_pdu *pdu)
{
    /**
     * For DSA - store data in MIB avaible table
     * For DSM - send the data to upper layer
     */
}
