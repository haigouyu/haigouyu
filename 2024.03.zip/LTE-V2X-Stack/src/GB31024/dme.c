#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#include "../../include/GB31024/dme.h"
#include "../../include/GB31024/adap.h"
#include "../../include/GB31024/dsmp.h"
#include "../../include/pdu_buf.h"
#include "../../include/GB31024/dsmp_encode.h"

struct dsmp_iex *create_dsa_iex(uint8_t repeat_rate, bool use_loc2d, uint32_t loc2d_latitude, uint32_t loc2d_longitude, bool use_loc3d,
                                uint32_t loc3d_latitude, uint32_t loc3d_longitude, uint32_t loc3d_elevation, uint16_t advert_len, uint8_t *advert_id)
{
    struct dsmp_iex *iex = calloc(1, sizeof(struct dsmp_iex));
    iex->count = 0;

    iex->repeat_rate = repeat_rate;
    iex->count++;
    iex->use[DSMP_EID_REPEAT_RATE] = 1;

    if (use_loc2d)
    {
        memcpy(iex->loc_2d.latitude, &loc2d_latitude, 4);
        memcpy(iex->loc_2d.longitude, &loc2d_longitude, 4);
        iex->count++;
        iex->use[DSMP_EID_2DLOCATION] = 1;
    }

    if (use_loc3d)
    {
        memcpy(iex->loc_3d.latitude, &loc3d_latitude, 4);
        memcpy(iex->loc_3d.longitude, &loc3d_longitude, 4);
        memcpy(iex->loc_3d.elevation, &loc3d_elevation, 2);
        iex->count++;
        iex->use[DSMP_EID_3DLOCATION] = 1;
    }

    if (advert_len != 0)
    {
        if (advert_len > 32)
        {
            // TODO: log an warning and avoid encoding
            printf("incorrect Advertiser Identifier");
        }
        else
        {
            iex->advert_id.len = advert_len;
            iex->count++;
            iex->use[DSMP_EID_ADVERTISER_ID] = 1;

            for (int i = 0; i < advert_len; i++)
                iex->advert_id.id[i] = advert_id[i];
        }
    }
    if (iex->count == 0)
    {
        return NULL;
    }
    return iex;
}

struct dsmp_iex *create_sii_iex(uint16_t psc_len, uint8_t *psc, uint8_t *ipaddr, uint16_t port, uint8_t *provider_mac, bool use_rcpi_thres,
                                int8_t rcpi_thres, bool use_count_thres, uint8_t count_thres, bool use_count_thres_interv, uint8_t count_thres_interv)
{
    struct dsmp_iex *iex = calloc(1, sizeof(struct dsmp_iex));
    iex->count = 0;
    if (psc_len != 0)
    {
        if (psc_len > 31)
        {
            // TODO: log warning msg net_error()
            printf("warning..too long provider service context\n");
        }
        else
        {
            iex->psc.len = psc_len;
            memcpy(iex->psc.psc, psc, psc_len);
            iex->count++;
            iex->use[DSMP_EID_PROVIDER_SERV_CONTEXT] = 1;
        }
    }

    if (strlen(ipaddr) != 0)
    {
        memcpy(iex->ip, ipaddr, 16);
        iex->count++;
        iex->use[DSMP_EID_IPV6_ADDRESS] = 1;

        memcpy(iex->port, &port, 2);
        iex->count++;
        iex->use[DSMP_EID_SERVICE_PORT] = 1;
    }

    if (strlen(provider_mac) != 0)
    {
        memcpy(iex->mac, provider_mac, 6);
        iex->count++;
        iex->use[DSMP_EID_PROVIDER_MAC_ADDRESS] = 1;
    }

    if (use_rcpi_thres)
    {
        if (rcpi_thres < -110 || rcpi_thres > 0)
        {
            // TODO: log warning msg
            printf("warning..rcpi_thres exceeded.\n");
        }
        else
        {
            iex->rcpi_thres = rcpi_thres;
            iex->count++;
            iex->use[DSMP_EID_RCPI_THRESHOLD] = 1;
        }
    }

    if (use_count_thres)
    {
        iex->count_thres = count_thres;
        iex->count++;
        iex->use[DSMP_EID_DSA_COUNT_THRESHOLD] = 1;
    }

    if (use_count_thres_interv)
    {
        if (count_thres_interv == 0)
        {
            // TODO: log warning msg
            printf("warning..count_thres_interv begin zero.\n");
        }
        else
        {
            iex->count_thres_int = count_thres_interv;
            iex->count++;
            iex->use[DSMP_EID_DSA_COUNT_THRES_INT] = 1;
        }
    }
    if (iex->count == 0)
    {
        return NULL;
    }
    return iex;
}

struct dsmp_iex *create_cii_iex(bool use_edac, uint8_t *ac_be, uint8_t *ac_bk, uint8_t *ac_vi, uint8_t *ac_vo, uint8_t chan_access)
{
    struct dsmp_iex *iex = calloc(1, sizeof(struct dsmp_iex));
    iex->count = 0;
    if (use_edac)
    {
        memcpy(iex->edca.ac_be, ac_be, 4);
        memcpy(iex->edca.ac_bk, ac_bk, 4);
        memcpy(iex->edca.ac_vi, ac_vi, 4);
        memcpy(iex->edca.ac_vo, ac_vo, 4);
        iex->count++;
        iex->use[DSMP_EID_EDCA_PARAMETER_SET] = 1;
    }

    if (chan_access > 2)
    {
        // log warning msg
        printf("log warining msg\n");
    }
    else
    {
        iex->chan_access = chan_access;
        iex->count++;
        iex->use[DSMP_EID_CHANNEL_ACCESS] = 1;
    }

    if (iex->count == 0)
    {
        return NULL;
    }
    return iex;
}

struct dsmp_sii *create_dsa_sii(uint32_t aid, uint8_t chan_index, uint16_t psc_len, uint8_t *psc, uint8_t *ipaddr, uint16_t port, uint8_t *provider_mac,
                                bool use_rcpi_thres, int8_t rcpi_thres, bool use_count_thres, uint8_t count_thres, bool use_count_thres_interv, uint8_t count_thres_interv)
{
    struct dsmp_sii *sii = calloc(1, sizeof(struct dsmp_sii));
    // TODO: Add value checks
    sii->aid = aid;
    sii->chan_index = chan_index;
    sii->iex = create_sii_iex(psc_len, psc, ipaddr, port, provider_mac, use_rcpi_thres, rcpi_thres, use_count_thres, count_thres,
                              use_count_thres_interv, count_thres_interv);
    sii->use_iex = sii->iex == NULL ? false : true;
    return sii;
}

struct dsmp_cii *create_dsa_cii(uint8_t op_class, uint8_t chan_no, int8_t tx_pow, uint8_t adapt, uint8_t data_rate, bool use_edac,
                                uint8_t *ac_be, uint8_t *ac_bk, uint8_t *ac_vi, uint8_t *ac_vo, uint8_t chan_access)
{
    struct dsmp_cii *cii = calloc(1, sizeof(struct dsmp_cii));
    // TODO: Add value checks
    cii->op_class = op_class;
    cii->chan = chan_no;
    cii->tx_pow = tx_pow;
    cii->adapt = adapt;
    cii->data_rate = data_rate;

    cii->iex = create_cii_iex(use_edac, ac_be, ac_bk, ac_vi, ac_vo, chan_access);
    cii->use_iex = cii->iex == NULL ? false : true;
    return cii;
}

/** TODO:
 *  1.wra is not supported. This primitive is not completed.
 *  2.DSA is sent periodically. So, do we need to create DSA each time?. can't we do the creation only when DSA related
 *    data updated on the MIB.
 */
struct dsmp_dsa *create_dsa_metadata(uint8_t dsa_id, ProviderServiceRequestTable *provider_serv_tb, ProviderChannelInfoTable *provider_chan_tb)
{
    struct dsmp_dsa *dsa = calloc(1, sizeof(struct dsmp_dsa));
    dsa->proto_version = DSMP_VERSION;
    dsa->dsaType = unsecured;
    dsa->version = DSMP_VERSION;
    if (dsa_id > 15)
    {
        // TODO: log an error
        return NULL;
    }
    dsa->id = dsa_id;
    dsa->content_count = 0; // TODO: This should be a global parameter. update whenever a change happen to DSA content. check extern in c

    // TODO: Advertiser Identifier need to be changed as required
    uint8_t advert_id[32] = "dummy-id";
    uint16_t advert_len = strlen(advert_id);

    uint32_t loc2d_latitude, loc2d_longitude, loc3d_latitude, loc3d_longitude, loc3d_elevation;
    bool use_loc2d = false, use_loc3d = false;

    ProviderServiceRequestTableEntry *entry = get_dme_prvtb(0, provider_serv_tb);
    if (entry == NULL)
        return NULL;

    // TODO: Need to figure out how to retrive, from where these 7 parameters can get.
    use_loc2d = true;
    loc2d_latitude = 1;
    loc2d_longitude = 1;

    use_loc3d = true;
    loc3d_latitude = 1;
    loc3d_longitude = 1;
    loc3d_elevation = 1;

    dsa->iex = create_dsa_iex(entry->ProviderRepeatRate, use_loc2d, loc2d_latitude, loc2d_longitude, use_loc3d, loc3d_latitude,
                              loc3d_longitude, loc3d_elevation, advert_len, advert_id);
    dsa->use_iex = dsa->iex == NULL ? false : true;

    dsa->sii_count = provider_serv_tb->size;
    if (dsa->sii_count > 0)
    {
        dsa->sis = calloc(dsa->sii_count, sizeof(struct dsmp_sii));
        int err_instances = 0;

        for (size_t i = 0; i < dsa->sii_count; i++)
        {
            entry = get_dme_prvtb(i, provider_serv_tb);

            // TODO: need to provide `ProviderIpService` parameter so that, we can say whether an IP or DSMP.
            // TODO: Need to figure out how to change these boolean values
            bool use_rcpi_thres = true;
            bool use_count_thres = true;
            bool use_count_thres_interv = true;

            struct dsmp_sii *sis = create_dsa_sii(
                entry->ProviderServiceIdentifier,
                get_chan_index(entry->ProviderServiceChannelNumber, provider_chan_tb),
                dme_prvtb_psc_len(entry->ProviderServiceContext), entry->ProviderServiceContext,
                entry->ProviderIpv6Address,
                entry->ProviderServicePort,
                entry->ProviderMacAddress,
                use_rcpi_thres, entry->ProviderRcpiThreshold,
                use_count_thres, entry->ProviderDsaCountThreshold,
                use_count_thres_interv, entry->ProviderDsaCountThresholdInterval);
            if (sis == NULL)
            {
                err_instances++;
                continue;
            }
            dsa->sis[i] = sis;
        }
        dsa->sii_count = dsa->sii_count - err_instances;
    }

    dsa->cii_count = provider_chan_tb->size;
    if (dsa->cii_count > 0)
    {
        dsa->cis = calloc(dsa->cii_count, sizeof(struct dsmp_cii));
        int err_instances = 0;
        ProviderChannelInfoTableEntry *chan_entry;

        for (int j = 0; j < dsa->cii_count; j++)
        {
            chan_entry = get_dme_prv_chan_entry(j, provider_chan_tb);
            uint8_t adapt = chan_entry->ProviderChannelInfoAdaptable ? 1 : 0;

            // TODO: These are just test values. Need to change accordingly.
            uint8_t ca_be[4] = "be";
            uint8_t ca_bk[4] = "bk";
            uint8_t ca_vi[4] = "vi";
            uint8_t ca_vo[4] = "vo";

            bool use_edca = true; // TODO: Need to change.

            uint8_t chan_access = alternatingTimeslot1Only; // we only support Provider to associate other devices during time slot 1.

            struct dsmp_cii *cii = create_dsa_cii(
                chan_entry->ProviderChannelInfoOperatingClass,
                chan_entry->ProviderChannelInfoChannelNumber,
                chan_entry->ProviderChannelInfoTransmitPowerLevel, adapt,
                chan_entry->ProviderChannelInfoDataRate,
                use_edca, ca_be, ca_bk, ca_vi, ca_vo, chan_access);
            if (cii == NULL)
            {
                err_instances++;
                continue;
            }
            dsa->cis[j] = cii;
        }
        dsa->cii_count = dsa->cii_count - err_instances;
    }

    // TODO: Since we are not supporting WRA, it is dropped from implementation. WRA part need to be supported in the future.
    dsa->use_wra = false;

    return dsa;
}

enum dme_service_confirm dme_provider_service_req(uint16_t local_service_index, enum action act, uint8_t *dest_mac_addr, enum dsa_type dsatype,
                                                  uint32_t aid, uint8_t *psc, uint8_t sch_id, uint8_t dsa_chan_id, enum time_slot chan_access, uint8_t repeat_rate,
                                                  bool ip_service, uint8_t *ipv6_addr, uint16_t service_port, uint8_t *provider_mac_addr, int8_t rcpi_threshold,
                                                  uint8_t dsa_count_threshold, uint8_t dsa_count_thd_interval, uint8_t info_elements_indicator, uint16_t sign_lifetime, mib_t *mib_db)
{

    if (act == add)
    {
        bool best_available = false; // Best Available option is set to `false` in our implementation.
        enum service_status serv_status = pending;
        if (IS_NOT_VALID_CHANNEL(sch_id))
        {
            sch_id = find_suitable_channel(); // Assign a suitable channel
        }
        if (IS_NOT_VALID_CHANNEL(dsa_chan_id))
        {
            dsa_chan_id = DEFAULT_CCH;
        }
        dme_prvtb_add(dsatype, aid, psc, chan_access, best_available, OPERATING_CLASS, sch_id, dsa_chan_id, repeat_rate, ip_service, ipv6_addr,
                      provider_mac_addr, service_port, rcpi_threshold, dsa_count_threshold, dsa_count_thd_interval, serv_status, mib_db->psrtb);

        uint8_t dsa_id = 4;
        int err[1];

        dsmp_pdu *pdu = create_pdu_buf();
        struct dsmp_dsa *dsa_metadata = create_dsa_metadata(dsa_id, mib_db->psrtb, mib_db->pcitb);
        dsmp_dsa_encode(dsa_metadata, pdu, err, DSMP_STRICT);
        if (*err)
        {
            printf("unable to encode DSA. error: %d", *err);
            return rejected_unspecified;
        }
        (mib_db->pdutb)->dsa_store[dsa_id] = pdu;
    }

    // else if(act == change){}
    // else if(act == delete){}
    return Accepted;
}

// TODO: Need to implement the channel assignment algorithm to pick a good channel for applicatioin service.
// Need to design algorithm, metadata etc
uint8_t find_suitable_channel()
{
    return 172;
}

enum dme_service_confirm dme_user_service_req(uint8_t local_service_indx, enum action act, enum user_request_type user_req_type, uint8_t *aid, uint8_t *psc,
                                              enum dsa_type dsatype, uint8_t channel_id, uint8_t *src_mac_addr, uint8_t *advert_id, uint8_t link_quality, uint8_t immediate_access,
                                              UserServiceRequestTable *user_serv_tb)
{
    /**
     * 1. population of a corresponding UserServiceRequestTableEntry in the MIB - done
     * 2. consideration of the service request in determining channel access assignments
     * 3. generates a DME-UserService.confirm indicating whether the request is accepted - return value from the function
     */
    uint8_t priority = 0;
    uint8_t op_class = OPERATING_CLASS;
    enum service_status serv_status = pending;
    if (act == add)
    {
        add_dme_user_serv_req_tb(user_req_type, aid, psc, priority, dsatype, src_mac_addr, advert_id, op_class, channel_id, link_quality,
                                 immediate_access, serv_status, user_serv_tb);
    }
    // else if(act == delete){}
    return Accepted;
}
