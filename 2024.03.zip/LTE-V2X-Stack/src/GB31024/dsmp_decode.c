
#include "../../include/GB31024/dsmp.h"
#include "../../include/GB31024/dsmp_encode.h"
#include "../../include/pdu_buf.h"
#include "../../include/net_err.h"

struct dsmp_dsa *dsmp_dsa_decode(dsmp_pdu *pdu, int *err, int mode)
{
    struct dsmp_dsa *ret = calloc(1, sizeof(struct dsmp_dsa));
    if (ret == NULL)
    {
        net_error(DSMP_ERROR, "unable to allocate memory to decode dsmp_dsa");
        return NULL;
    }
    size_t i[1];

    uint8_t *msg = calloc(pdu->offset, 1);
    if (msg == NULL)
    {
        net_error(DSMP_ERROR, "unable to allocate memory to decode dsa");
        return NULL;
    }
    memcpy(msg, pdu->current, pdu->offset);
    size_t len = pdu->offset;
    *i = 0;
    *err = 0;

    if (mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE)
    {
        fprintf(stderr, "ERROR: mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE\n");
        *err = -DSMP_EMODE;
        goto out;
    }

    if (len < DSMP_DSA_MIN || len > DSMP_MAXSIZE)
    {
        fprintf(stderr, "ERROR: len < DSMP_WSA_MIN || len > DSMP_MAXSIZE\n");
        *err = -DSMP_EFAULT;
        goto out;
    }

    uint8_t tmp = 0;

    _g(msg, i, &tmp, len, err);
    ret->proto_version = tmp;

    _g(msg, i, &tmp, len, err);
    ret->dsaType = tmp;

    _g(msg, i, &tmp, len, err);

    ret->version = tmp >> 4;

    if (ret->version != DSMP_VERSION)
    {
        fprintf(stderr, "ERROR: ret->version != DSMP_VERSION\n");
        *err = -DSMP_ENOSUPPORT;
        goto out;
    }

    uint8_t hoi = tmp & 0x0F;

    ret->use_iex = (hoi & 0x08) >> 3;
    ret->sii_count = (hoi & 0x04) >> 2;
    ret->cii_count = (hoi & 0x02) >> 1;
    ret->use_wra = (hoi & 0x01);

    _g(msg, i, &tmp, len, err);

    ret->id = tmp >> 4;
    ret->content_count = tmp & 0x0F;

    if (ret->use_iex)
    {
        size_t iex_cnt = *i;
        struct dsmp_iex *iex = dsmp_iex_decode(msg, &iex_cnt, len, err, mode);

        *i = iex_cnt;
        ret->iex = iex;
    }

    int j = 0;

    if (ret->sii_count)
    {
        _g_c(msg, i, &ret->sii_count, len, err);
        ret->sis = calloc(ret->sii_count, sizeof(struct dsmp_sii));

        for (j = 0; j < ret->sii_count; j++)
        {
            size_t sii_cnt = *i;
            struct dsmp_sii *sii = dsmp_sii_decode(msg, &sii_cnt, len, err, mode);

            *i = sii_cnt;
            ret->sis[j] = sii;
        }
    }

    if (ret->cii_count)
    {
        _g_c(msg, i, &ret->cii_count, len, err);
        ret->cis = calloc(ret->cii_count, sizeof(struct dsmp_cii));

        for (j = 0; j < ret->cii_count; j++)
        {
            size_t cii_cnt = *i;
            struct dsmp_cii *cii = dsmp_cii_decode(msg, &cii_cnt, len, err, mode);

            *i = cii_cnt;
            ret->cis[j] = cii;
        }
    }

    if (ret->use_wra)
    {
        size_t wra_cnt = *i;
        struct dsmp_wra *wra = dsmp_wra_decode(msg, &wra_cnt, len, err, mode);

        *i = wra_cnt;
        ret->wra = wra;
    }

    /* if (*i != len) { */
    /*		  fprintf(stderr, "ERROR: *i != len\n"); */
    /*		  *err = -DSMP_EFAULT; */
    /*		  goto out; */
    /* } */

out:
    pdu->offset -= *i;
    pdu->current += *i;
    free(msg);
    return ret;
}

struct dsmp_dsm *dsmp_dsm_decode(dsmp_pdu *pdu, int *err, int mode)
{
    struct dsmp_dsm *ret = calloc(1, sizeof(struct dsmp_dsm));
    if (ret == NULL)
    {
        // TODO: *err=?
        net_error(DSMP_ERROR, "unable to allocate memory to decode dsmp_dsm");
        return NULL;
    }
    size_t i[1];

    uint8_t *msg = calloc(pdu->offset, 1);
    if (msg == NULL)
    {
        // TODO: *err=?
        net_error(DSMP_ERROR, "unable to allocate memory to decode dsm");
        return NULL;
    }
    memcpy(msg, pdu->current, pdu->offset);
    size_t len = pdu->offset;
    *i = 0;
    *err = 0;

    if (mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE)
    {
        fprintf(stderr, "ERROR: mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE\n");
        *err = -DSMP_EMODE;
        goto out;
    }

    if (len < DSMP_DSM_MIN || len > DSMP_MAXSIZE)
    {
        fprintf(stderr, "ERROR: len < DSMP_DSM_MIN || len > DSMP_MAXSIZE\n");
        *err = -DSMP_EFAULT;
        goto out;
    }

    uint8_t tmp = 0;
    _g(msg, i, &tmp, len, err);

    ret->subtype = tmp >> 4;
    ret->use_n_iex = (tmp & 0x0F) >> 3;
    ret->version = tmp & 0x07;

    if (mode != DSMP_LOOSE && ret->subtype > 4)
    {
        fprintf(stderr, "ERROR: mode != DSMP_LOOSE && curs->subtype > 4\n");
        *err = -DSMP_EDOMAIN;
        goto out;
    }
    else if (ret->version != DSMP_VERSION)
    {
        fprintf(stderr, "ERROR: ret->version != DSMP_VERSION\n");
        *err = DSMP_ENOSUPPORT;
        goto out;
    }

    if (ret->use_n_iex)
    {
        size_t n_iex_cnt = *i;
        struct dsmp_iex *n_iex = dsmp_iex_decode(msg, &n_iex_cnt, len, err, mode);

        *i = n_iex_cnt;
        ret->n_iex = n_iex;
    }
    _g(msg, i, &tmp, len, err);

    ret->tpid = tmp;

    if (ret->tpid > 5)
    {
        fprintf(stderr, "ERROR: ret->tpid > 5\n");
        *err = -DSMP_ENOSUPPORT;
        goto out;
    }

    if (ret->tpid < 2)
    {
        _g_p(msg, i, &ret->aid, len, err);
    }
    else
    {
        _g_n(msg, i, 2, ret->ports.src, len, err);
        _g_n(msg, i, 2, ret->ports.dst, len, err);
    }

    if (ret->tpid % 2 == 1)
    {
        ret->use_t_iex = 1;

        size_t t_iex_cnt = *i;
        struct dsmp_iex *t_iex = dsmp_iex_decode(msg, &t_iex_cnt, len, err, mode);

        *i = t_iex_cnt;
        ret->t_iex = t_iex;
    }

    _g_c(msg, i, &ret->len, len, err);

    if (mode == DSMP_STRICT && ret->len == 0)
    {
        fprintf(stderr, "ERROR: mode == DSMP_STRICT && ret->len == 0\n");
        *err = -DSMP_EDOMAIN;
        goto out;
    }

    ret->data = calloc(ret->len, 1);

    _g_n(msg, i, ret->len, ret->data, len, err);

    /* if (*i != len) { */
    /*		  fprintf(stderr, "ERROR: *i != len\n"); */
    /*		  *err = -DSMP_EFAULT; */
    /*		  goto out; */
    /* } */

out:
    pdu->offset -= *i;
    pdu->current += *i;
    free(msg);
    return ret;
}
