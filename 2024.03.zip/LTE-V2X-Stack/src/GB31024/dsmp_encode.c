
#include "../../include/GB31024/dsmp.h"
#include "../../include/GB31024/dsmp_encode.h"
#include "../../include/pdu_buf.h"

void dsmp_dsa_encode(const struct dsmp_dsa *curs, dsmp_pdu *pdu, int *err, int mode)
{
    uint8_t buf[DSMP_MAXSIZE];
    size_t i[1];

    *i = 0;
    *err = 0;

    if (mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE)
    {
        fprintf(stderr, "ERROR: mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE\n");
        *err = -DSMP_EMODE;
        goto out;
    }

    if (curs->version != DSMP_VERSION)
    {
        fprintf(stderr, "ERROR: curs->version != DSMP_VERSION\n");
        *err = -DSMP_ENOSUPPORT;
        goto out;
    }
    _s(buf, i, curs->proto_version, DSMP_MAXSIZE, err);
    _s(buf, i, curs->dsaType, DSMP_MAXSIZE, err);

    uint8_t hoi = 0x00;

    if (curs->use_iex)
        hoi |= 0b1000;
    if (curs->sii_count > 0)
        hoi |= 0b0100;
    if (curs->cii_count > 0)
        hoi |= 0b0010;
    if (curs->use_wra)
        hoi |= 0b0001;

    _s(buf, i, (curs->version << 4) | hoi, DSMP_MAXSIZE, err);

    if (curs->id > 15 || curs->content_count > 15)
    {
        fprintf(stderr, "ERROR: curs->id > 15 || curs->content_count > 15\n");
        *err = -DSMP_EBADMSG;
        goto out;
    }

    _s(buf, i, (curs->id << 4) | curs->content_count, DSMP_MAXSIZE, err);

    if (curs->use_iex)
    {
        size_t iex_cnt = 0;
        uint8_t *iex_buf = dsmp_iex_encode(curs->iex, &iex_cnt, err, mode);

        _s_n(buf, i, iex_cnt, iex_buf, DSMP_MAXSIZE, err);
        free(iex_buf);
    }

    int j = 0;

    if (curs->sii_count > 0)
    {
        if (mode == DSMP_STRICT && curs->sii_count == 0)
        {
            fprintf(stderr, "ERROR: mode == DSMP_STRICT && curs->sii_count == 0\n");
            *err = -DSMP_EDOMAIN;
            goto out;
        }
        else if (curs->sii_count > 31)
        {
            fprintf(stderr, "ERROR: curs->sii_count > 31\n");
            *err = -DSMP_EBADMSG;
            goto out;
        }

        _s_c(buf, i, curs->sii_count, DSMP_MAXSIZE, err);

        for (j = 0; j < curs->sii_count; j++)
        {
            size_t sii_cnt = 0;
            uint8_t *sii_buf = dsmp_sii_encode(curs->sis[j], &sii_cnt, err, mode);

            _s_n(buf, i, sii_cnt, sii_buf, DSMP_MAXSIZE, err);
            free(sii_buf);
        }
    }

    if (curs->cii_count > 0)
    {
        if (mode == DSMP_STRICT && curs->cii_count == 0)
        {
            fprintf(stderr, "ERROR: mode == DSMP_STRICT && curs->cii_count == 0\n");
            *err = -DSMP_EDOMAIN;
            goto out;
        }
        else if (curs->cii_count > 31)
        {
            fprintf(stderr, "ERROR: curs->cii_count > 31\n");
            *err = -DSMP_EBADMSG;
            goto out;
        }

        _s_c(buf, i, curs->cii_count, DSMP_MAXSIZE, err);

        for (j = 0; j < curs->cii_count; j++)
        {
            size_t cii_cnt = 0;
            uint8_t *cii_buf = dsmp_cii_encode(curs->cis[j], &cii_cnt, err, mode);

            _s_n(buf, i, cii_cnt, cii_buf, DSMP_MAXSIZE, err);
            free(cii_buf);
        }
    }

    if (curs->use_wra)
    {
        size_t wra_cnt = 0;
        uint8_t *wra_buf = dsmp_wra_encode(curs->wra, &wra_cnt, err, mode);

        _s_n(buf, i, wra_cnt, wra_buf, DSMP_MAXSIZE, err);
        free(wra_buf);
    }

out:
    add_data_to_pbuf(pdu, buf, *i, err);
}



void dsmp_dsm_encode(const struct dsmp_dsm *curs, dsmp_pdu *pdu, int *err, int mode)
{
    uint8_t buf[DSMP_MAXSIZE];
    size_t i[1];

    *i = 0;
    *err = 0;

    if (mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE)
    {
        fprintf(stderr, "ERROR: mode != DSMP_STRICT && mode != DSMP_LAX && mode != DSMP_LOOSE\n");
        *err = -DSMP_EMODE;
        goto out;
    }
    if (mode != DSMP_LOOSE && curs->subtype > 4)
    {
        fprintf(stderr, "ERROR: mode != DSMP_LOOSE && curs->subtype > 4\n");
        *err = -DSMP_EDOMAIN;
        goto out;
    }
    else if (curs->version != DSMP_VERSION)
    {
        fprintf(stderr, "ERROR: curs->version != DSMP_VERSION\n");
        *err = -DSMP_ENOSUPPORT;
        goto out;
    }

    _s(buf, i, (curs->subtype << 4) | (curs->use_n_iex << 3) | curs->version, DSMP_MAXSIZE, err);

    if (curs->use_n_iex)
    {
        size_t n_iex_cnt = 0;
        uint8_t *n_iex_buf = dsmp_iex_encode(curs->n_iex, &n_iex_cnt, err, mode);

        _s_n(buf, i, n_iex_cnt, n_iex_buf, DSMP_MAXSIZE, err);
        free(n_iex_buf);
    }

    if (curs->tpid > 5)
    {
        fprintf(stderr, "ERROR: curs->tpid > 5\n");
        *err = -DSMP_ENOSUPPORT;
        goto out;
    }

    _s(buf, i, curs->tpid, DSMP_MAXSIZE, err);

    if (curs->tpid < 2)
    {
        _s_p(buf, i, curs->aid, DSMP_MAXSIZE, err);
    }
    else
    {
        _s_n(buf, i, 2, curs->ports.src, DSMP_MAXSIZE, err);
        _s_n(buf, i, 2, curs->ports.dst, DSMP_MAXSIZE, err);
    }

    uint8_t tmp = curs->tpid % 2 == 1;

    if ((tmp && !curs->use_t_iex) || (!tmp && curs->use_t_iex))
    {
        fprintf(stderr, "ERROR: (tmp && !curs->use_t_iex) || (!tmp && curs->use_t_iex)\n");
        *err = -DSMP_EBADMSG;
        goto out;
    }

    if (curs->use_t_iex)
    {
        size_t t_iex_cnt = 0;
        uint8_t *t_iex_buf = dsmp_iex_encode(curs->t_iex, &t_iex_cnt, err, mode);

        _s_n(buf, i, t_iex_cnt, t_iex_buf, DSMP_MAXSIZE, err);
        free(t_iex_buf);
    }

    if (mode == DSMP_STRICT && curs->len == 0)
    {
        fprintf(stderr, "ERROR: mode == DSMP_STRICT && curs->len == 0\n");
        *err = -DSMP_EDOMAIN;
        goto out;
    }

    _s_c(buf, i, curs->len, DSMP_MAXSIZE, err);
    _s_n(buf, i, curs->len, curs->data, DSMP_MAXSIZE, err);

out:
    add_data_to_pbuf(pdu, buf, *i, err);
}
