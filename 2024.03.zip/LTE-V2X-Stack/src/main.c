#include <stdio.h>
#include <pthread.h>
#include <time.h>
#include <unistd.h>
#include "../include/controller.h"
#include "../include/GB31024/dme.h"
pthread_cond_t chan_timer;
pthread_mutex_t mutex_slot;

int main()
{
    pthread_t timer_th, scheduler_th; // 创建线程
    // 初始化互斥锁、条件变量
    slot_mutex_init();
    timer_cond_init();

    mib_t *mib_db = create_mib(); // 创建MIB数据库

    // 创建并启动定时器线程
    if (pthread_create(&timer_th, NULL, &timer, NULL) != 0)
        return 1;

    if (pthread_create(&scheduler_th, NULL, &scheduler, (void *)mib_db) != 0)
        return 1;

    // 初始化服务器套接字
    int server_fd = server_init(SCKFILE);
    if (server_fd == -1)
        return 1;
    // 监听客户端连接
    server_listen(server_fd, mib_db);

    // 清理资源
    slot_mutex_destroy();
    timer_cond_destroy();
    return 0;
}
