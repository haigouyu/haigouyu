#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "../include/net_err.h"

//extern int errno;

// TODO: How to carry addtional data like err_code etc.
void net_error(char *level, char *reason)
{
    fprintf(stderr, "%s : %s, %s\n", level, reason, strerror(errno));
}

void net_panic(char *reason)
{
    net_error(DSMP_PANIC, reason);
    exit(EXIT_FAILURE);
}