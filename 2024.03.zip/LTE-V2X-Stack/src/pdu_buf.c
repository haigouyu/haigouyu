#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/pdu_buf.h"
#include "../include/net_err.h"
#include "../include/GB31024/dsmp.h"

void show_pdu(dsmp_pdu *self)
{
    printf("head: %p\n", self->head);
    printf("end : %p\n", self->end);
    printf("current: %p\n", self->current);
    printf("offset : %p, value: %ld\n", &(self->offset), self->offset);
}

/**
 * create pdu_buf and return data structure called dsmp_pdu to handle pdu_buf.
 * pdu.current - upto where data is filled.
 * pdu.offset - offset from pdu.current to pdu.end in octets.
 */
dsmp_pdu *create_pdu_buf()
{
    uint8_t *pdu_buf = calloc(DSMP_MAXSIZE, 1);
    if (pdu_buf == NULL)
        net_error(DSMP_ERROR, "could not allocate memory to create pdu-buf");

    dsmp_pdu *pdu = malloc(sizeof(dsmp_pdu));
    if (pdu == NULL)
        net_error(DSMP_ERROR, "could not allocate memory to create dsmp pdu");

    pdu->head = pdu_buf;
    pdu->end = pdu_buf + (size_t)DSMP_MAXSIZE;
    pdu->current = pdu->end;
    pdu->offset = 0;
    return pdu;
}

/**
 * add data with given size to pdu_buf from left to right. only support
 * uint8_t data pointers. if pdu_buf size is not enough operation will cancel.(pdu_buf size won't increase automatically)
 */
void add_data_to_pbuf(dsmp_pdu *pdu, uint8_t *data, size_t szof_data, int *err)
{
    uint8_t *st = pdu->current - szof_data;
    if (st < pdu->head)
    {
        // pdu_buf size is not enough
        *err = DSMP_EPBUF;
        net_error(DSMP_WARN, "pdu_buf size is exceeded for a DSM data");
        return;
    }
    memcpy(st, data, szof_data);
    pdu->current = st;
    pdu->offset += szof_data;
}

void read_from_pbuf(dsmp_pdu *pdu, size_t szof_data, uint8_t *ret, int *err)
{
    if (pdu->current > pdu->end)
    {
        // err = ?
        // log relavent error
        return;
    }
    memcpy(ret, pdu->current, szof_data);
    pdu->current += szof_data;
    pdu->offset -= szof_data;
}

void free_pbuf(dsmp_pdu *pdu)
{
    free(pdu->head);
    free(pdu);
}

PduTable *create_pduTable()
{
    PduTable *pdu_tb = calloc(1, sizeof(PduTable));
    if (pdu_tb == NULL)
        net_panic("unable to allocate memory to create PDU table");
    pdu_tb->dsa_store = calloc(16, sizeof(dsmp_pdu));
    if (pdu_tb->dsa_store == NULL)
        net_panic("unable to allocate memory to create dsmp_pdu struct");
    return pdu_tb;
}

dsmp_pdu *get_pdu(uint8_t indx, PduTable *pdu_tb)
{
    return pdu_tb->dsa_store[indx];
}
