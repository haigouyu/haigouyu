#ifndef _NET_ERROR_H
#define _NET_ERROR_H

#define DSMP_ERROR "Error"
#define DSMP_WARN "Warn"
#define DSMP_DEBUG "Debug"
#define DSMP_PANIC "Panic"

void net_error(char *level, char *reason);
void net_panic(char *reason);

#endif /* _NET_ERROR_H */
