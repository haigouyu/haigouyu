#ifndef _DSMP_NETWORK_H
#define _DSMP_NETWORK_H

#include "pdu_buf.h"

char *get_network_device(); // what if multiple network devices are availble.
uint8_t *get_mac_addr(char *device);
void write_tun(dsmp_pdu *pdu);

#endif /* _DSMP_NETWORK_H */
