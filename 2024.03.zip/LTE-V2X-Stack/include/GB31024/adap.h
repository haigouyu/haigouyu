#ifndef _DSMP_ADA_H
#define _DSMP_ADA_H

#include <stdint.h>
#include "../pdu_buf.h"

#include "dsmp.h"

/* TODO: DsmMaxLength and this variable is similary which is maintain under MIB */
#define MSDU_MAXSIZE 2304 /* in octets */

#define DSMP_ADA_DSAP 0xAA
#define DSMP_ADA_SSAP 0xAA
#define DSMP_ADA_CONTROL 0x03
#define DSMP_ADA_OUI 0x000000
#define DSMP_ADA_ETHERTYPE_IP 0x86DD
#define DSMP_ADA_ETHERTYPE_DSMP 0x88DC

/* This will be used to create ADA PDU(MSDU) which is inserted into data field of MA-UNITDATAX.request */
typedef struct ada_pdu_metadata
{
    uint8_t dsap;
    uint8_t ssap;
    uint8_t control;
    uint8_t oui[3];
    uint16_t ethertype;
} ada_pdu_metadata;

ada_pdu_metadata *init_ada_pdu_metadata(uint16_t ethertype);
void print_ada_pdu_metadata(const ada_pdu_metadata *self);
void ada_encode(const ada_pdu_metadata *self, dsmp_pdu *pdu, int *err);
ada_pdu_metadata *ada_decode(dsmp_pdu *pdu, int *err);
void free_ada_pdu_metadata(ada_pdu_metadata *self);
void dl_unitdatax_req(dsmp_pdu *pdu, uint8_t *src_addr, uint8_t *dest_addr, uint8_t prority, uint8_t chan_id,
                      enum time_slot timeslot, uint8_t data_rate, uint8_t txpwr_level, uint8_t channel_load, uint64_t wsm_expire_time, int *err);
void dl_unitdata_ind(ada_pdu_metadata *ada_metadata, dsmp_pdu *pdu, int *err);
void dl_recv(int *err);

#endif /* _DSMP_ADA_H */