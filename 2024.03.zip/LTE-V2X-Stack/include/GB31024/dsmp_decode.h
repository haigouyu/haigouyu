#ifndef _DSMP_DECODE_H
#define _DSMP_DECODE_H

/* DSRC Short Message Protocol - GB/T 31024 */

#include <stdint.h>
#include <stdio.h>
#include "../pdu_buf.h"

struct dsmp_iex *dsmp_iex_decode(const uint8_t *msg, size_t *cnt, size_t len, int *err, int mode);
struct dsmp_sii *dsmp_sii_decode(const uint8_t *msg, size_t *cnt, size_t len, int *err, int mode);
struct dsmp_cii *dsmp_cii_decode(const uint8_t *msg, size_t *cnt, size_t len, int *err, int mode);
struct dsmp_wra *dsmp_dra_decode(const uint8_t *msg, size_t *cnt, size_t len, int *err, int mode);
struct dsmp_dsa *dsmp_dsa_decode(dsmp_pdu *pdu, int *err, int mode);
struct dsmp_dsm *dsmp_dsm_decode(dsmp_pdu *pdu, int *err, int mode);

#endif /* _DSMP_DECODE_H */
