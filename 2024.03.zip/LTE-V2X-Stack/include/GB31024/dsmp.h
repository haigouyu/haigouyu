#ifndef _DSMP_H
#define _DSMP_H

#include <asm/errno.h>
#include <asm/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>

#include "../../include/GB31024/dme.h"

#define DSMP_EID_TX_POWER_USED_80211 4
#define DSMP_EID_2DLOCATION 5
#define DSMP_EID_3DLOCATION 6
#define DSMP_EID_ADVERTISER_ID 7
#define DSMP_EID_PROVIDER_SERV_CONTEXT 8
#define DSMP_EID_IPV6_ADDRESS 9
#define DSMP_EID_SERVICE_PORT 10
#define DSMP_EID_PROVIDER_MAC_ADDRESS 11
#define DSMP_EID_EDCA_PARAMETER_SET 12
#define DSMP_EID_SECONDARY_DNS 13
#define DSMP_EID_GATEWAY_MAC_ADDRESS 14
#define DSMP_EID_CHANNEL_NUMBER_80211 15
#define DSMP_EID_DATA_RATE_80211 16
#define DSMP_EID_REPEAT_RATE 17
#define DSMP_EID_RCPI_THRESHOLD 19
#define DSMP_EID_DSA_COUNT_THRESHOLD 20
#define DSMP_EID_CHANNEL_ACCESS 21
#define DSMP_EID_DSA_COUNT_THRES_INT 22
#define DSMP_EID_CHANNEL_LOAD 23

#define DSMP_MAXSIZE 2304

#define DSMP_DSM_MIN 3
#define DSMP_DSA_MIN 2
#define DSMP_SII_MIN 2
#define DSMP_CII_MIN 5
#define DSMP_WRA_MIN 52 /* 52 with IEX padding */
#define DSMP_IEX_MIN 1

#define DSMP_MAXCOUNT 16383

#define DSMP_A1_AMIN 0x00000000
#define DSMP_A2_AMIN 0x00008000
#define DSMP_A3_AMIN 0x00C00000
#define DSMP_A4_AMIN 0xE0000000

#define DSMP_A1_AMAX 0x0000007F
#define DSMP_A2_AMAX 0x0000BFFF
#define DSMP_A3_AMAX 0x00DFFFFF
#define DSMP_A4_AMAX 0xEFFFFFFF

#define DSMP_A2_AXOR 0x00008000
#define DSMP_A3_AXOR 0x00C00000
#define DSMP_A4_AXOR 0xE0000000

#define DSMP_A1_MAX 0x0000007F
#define DSMP_A2_MAX 0x0000407F
#define DSMP_A3_MAX 0x0020407F
#define DSMP_A4_MAX 0x1020407F

#define DSMP_A2_OFF 0x00007F80
#define DSMP_A3_OFF 0x00BFBF80
#define DSMP_A4_OFF 0xDFDFBF80

#define DSMP_VERSION 3

#define DSMP_DSMP_PREFIX 0x86DD
#define DSMP_IPV6_PREFIX 0x88DD

#define DSMP_STRICT 0
#define DSMP_LAX 1
#define DSMP_LOOSE 2

#define DSMP_ENOSUPPORT EOPNOTSUPP
#define DSMP_EBADMSG EBADMSG
#define DSMP_EDOMAIN EINVAL
#define DSMP_EFAULT EFAULT
#define DSMP_EMODE EPROTOTYPE
#define DSMP_EDUPLICATE EMLINK
#define DSMP_ENOMEM ENOMEM
#define DSMP_EPBUF 201 /* DSM data is too big */

#define DSMP_DSM 0
#define DSMP_DSA 1

/* GB/T 31024.3 DATA TYPES */

struct dsmp_ie_raw
{
    uint8_t id;
    uint16_t len; /* 0 to 16383 */
    uint8_t *data;
};

struct dsmp_ie_psc
{
    uint16_t len; /* 0 to 31 */
    uint8_t psc[31];
};

struct dsmp_ie_edca
{
    uint8_t ac_be[4];
    uint8_t ac_bk[4];
    uint8_t ac_vi[4];
    uint8_t ac_vo[4];
};

struct dsmp_ie_2d
{
    uint8_t latitude[4];
    uint8_t longitude[4];
};

struct dsmp_ie_3d
{
    uint8_t latitude[4];
    uint8_t longitude[4];
    uint8_t elevation[2];
};

struct dsmp_ie_advert_id
{
    uint16_t len; /* 0 to 32 */
    uint8_t id[32];
};

struct dsmp_iex
{
    uint16_t count; /* TODO: 0-127 : 8 bits, 128-255 : 16 bits */

    /* DSM Elements */
    uint8_t chan;      /* 0 to 200 */
    uint8_t data_rate; /* 2 to 127 */
    int8_t tx_pow;     /* -128 to 127 */
    // uint8_t channel_load;

    /* SII Elements */
    struct dsmp_ie_psc psc;
    uint8_t ip[16];
    uint8_t port[2];
    uint8_t mac[6];
    int8_t rcpi_thres; /* -110 to 0 */
    uint8_t count_thres;
    uint8_t count_thres_int; /* 1 to 255 */

    /* CII Elements */
    struct dsmp_ie_edca edca;
    uint8_t chan_access; /* 0 to 2 */

    /* DSA Elements */
    uint8_t repeat_rate; // 0-255
    struct dsmp_ie_2d loc_2d;
    struct dsmp_ie_3d loc_3d;
    struct dsmp_ie_advert_id advert_id;

    /* WRA Elements */
    uint8_t sec_dns[16];
    uint8_t gateway_mac[6];

    bool use[DSMP_EID_CHANNEL_LOAD + 1];

    uint16_t raw_count;
    struct dsmp_ie_raw *raw;
};

struct dsmp_dsm
{
    /* N-Header */
    uint8_t subtype; /* 0 to 15 */
    uint8_t version; /* DSMP_VERSION */
    uint8_t tpid;    /* 0 to 5 */

    bool use_n_iex;
    struct dsmp_iex *n_iex;

    /* T-Header */
    union
    {
        uint32_t aid; /* 0x0 to 0xEFFFFFFF */

        struct
        {
            uint8_t src[2];
            uint8_t dst[2];
        } ports;
    };

    bool use_t_iex;
    struct dsmp_iex *t_iex;

    uint16_t len; /* 0 to 16383 */
    uint8_t *data;
};

struct dsmp_sii
{
    uint32_t aid;
    uint8_t chan_index; /* 0 to 31 */

    bool use_iex;
    struct dsmp_iex *iex;
};

struct dsmp_cii
{
    uint8_t op_class;  /* TODO: 802.11 */
    uint8_t chan;      /* TODO: 802.11 */
    int8_t tx_pow;     /* -128 to 127 */
    uint8_t adapt;     /* 0 to 1 */
    uint8_t data_rate; /* 0x02 to 0x7F */

    bool use_iex;
    struct dsmp_iex *iex;
};

struct dsmp_wra
{
    uint8_t lifetime[2];   /* TODO: IETF RFC 4861 */
    uint8_t ip_prefix[16]; /* TODO: IETF RFC 4861 */
    uint8_t prefix_len;    /* TODO: IETF RFC 4861 */
    uint8_t gateway[16];
    uint8_t dns[16];

    bool use_iex;
    struct dsmp_iex *iex;
};

struct dsmp_dsa
{
    uint8_t proto_version; // Ieee1609Dot2Data fields (IEEE 1609.2 Std)
    enum dsa_type dsaType;
    uint8_t version;       /* 0 to 15 */
    uint8_t id;            /* DSA Identifier, 0 to 15 */
    uint8_t content_count; /* 0 to 15 */

    bool use_iex;
    struct dsmp_iex *iex;

    uint16_t sii_count; /* 0 to 31 */
    struct dsmp_sii **sis;

    uint16_t cii_count; /* 0 to 31 */
    struct dsmp_cii **cis;

    bool use_wra;
    struct dsmp_wra *wra;
};

// valid ranges for confirm the acceptance of a DSM.
enum confirm_result_code
{
    accepted,
    rejected_max_length_exceeded,
    rejected_unspecified
};

void free_iex(struct dsmp_iex *curs);
void free_sii(struct dsmp_sii *curs);
void free_cii(struct dsmp_cii *curs);
void free_wra(struct dsmp_wra *curs);
void free_dsa(struct dsmp_dsa *curs);
void free_dsm(struct dsmp_dsm *curs);

uint8_t c_count(uint8_t c);

uint8_t p_count(uint8_t p_c);
uint32_t p_to_hex(uint32_t aid, uint8_t *len);
uint32_t hex_to_p(uint32_t aid, uint8_t *len);

void _g(const uint8_t *buf, size_t *i, uint8_t *v, size_t len, int *err);
void _gs(const uint8_t *buf, size_t *i, int8_t *v, size_t len, int *err);
void _g_n(const uint8_t *buf, size_t *i, size_t n, uint8_t *v, size_t len, int *err);
void _g_p(const uint8_t *buf, size_t *i, uint32_t *v, size_t len, int *err);
void _g_c(const uint8_t *buf, size_t *i, uint16_t *v, size_t len, int *err);

void _s(uint8_t *buf, size_t *i, const uint8_t v, size_t len, int *err);
void _s_n(uint8_t *buf, size_t *i, size_t n, const uint8_t *v, size_t len, int *err);
void _s_p(uint8_t *buf, size_t *i, const uint32_t v, size_t len, int *err);
void _s_c(uint8_t *buf, size_t *i, const uint16_t v, size_t len, int *err);

struct dsmp_dsm *create_dsmp_metadata(uint8_t subtype, uint8_t tpid, uint8_t info_elem_indicator, uint8_t chan_id, uint8_t data_rate,
                                      int8_t tx_pow, uint32_t aid, uint16_t len, uint8_t *data);
struct dsmp_iex *create_n_iex(uint8_t chan_id, uint8_t data_rate, int8_t tx_pow);
enum confirm_result_code dsm_dsmpshortmsg_req(uint8_t chan_id, enum time_slot timeslot, uint8_t data_rate, int8_t tx_power, uint8_t channel_load,
                                              uint8_t info_elem_indicator, uint8_t prority, uint64_t dsm_expire_time, uint16_t len, uint8_t *data, uint8_t *peer_mac_addr, uint32_t aid);

/* int dsmp_ioctl(struct socket *sock, unsigned int cmd, unsigned long arg); */
/* int dsmp_send(struct sk_buff *skb, int loop); */
/* int dsmp_receive(struct sk_buff *skb, struct net_device *dev); */

#endif /* _DSMP_COMMON_H */
