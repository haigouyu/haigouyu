#ifndef _DSMP_ENCODE_H
#define _DSMP_ENCODE_H

/* DSRC Short Message Protocol - GB/T 31024.3*/

#include <stdint.h>
#include <stdio.h>
#include "../pdu_buf.h"

uint8_t *dsmp_iex_encode(const struct dsmp_iex *curs, size_t *cnt, int *err, int mode);
uint8_t *dsmp_sii_encode(const struct dsmp_sii *curs, size_t *cnt, int *err, int mode);
uint8_t *dsmp_cii_encode(const struct dsmp_cii *curs, size_t *cnt, int *err, int mode);
uint8_t *dsmp_wra_encode(const struct dsmp_wra *curs, size_t *cnt, int *err, int mode);
void dsmp_dsa_encode(const struct dsmp_dsa *curs, dsmp_pdu *pdu, int *err, int mode);
void dsmp_dsm_encode(const struct dsmp_dsm *curs, dsmp_pdu *pdu, int *err, int mode);

#endif /* _DSMP_ENCODE_H */
