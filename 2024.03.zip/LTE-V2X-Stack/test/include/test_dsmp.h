#ifndef _TEST_WSMP_H
#define _TEST_WSMP_H

#include "../../include/GB31024/dsmp.h"

void print_bin8(uint8_t value);
void print_binx(uint8_t *buf, size_t size);

void print_dsm(struct dsmp_dsm *dsm);
void print_sii(struct dsmp_sii *sii);
void print_cii(struct dsmp_cii *cii);
void print_wra(struct dsmp_wra *wra);
void print_dsa(struct dsmp_dsa *dsa);

struct dsmp_dsm *gen_dsm_metadata();
enum confirm_result_code gen_dsm_waveshortmsg_req();

#endif /* _TEST_WSMP_H */
