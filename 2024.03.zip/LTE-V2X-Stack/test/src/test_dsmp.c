

#include "../include/test_dsmp.h"
#include "../../include/GB31024/dsmp.h"
#include "../../include/pdu_buf.h"
#include "../../include/GB31024/adap.h"

void print_iex(struct dsmp_iex *iex) {
     printf("\n---- fields in dsmp_iex struct ----\n");
     printf("count:            %d\n", iex->count);
     printf("chan:             %d\n", iex->chan);
     printf("data rate:        %d\n", iex->data_rate);
     printf("tx_pow:           %d\n", iex->tx_pow);
     printf("psc.len:          %d\n", iex->psc.len);
     printf("psc.data:\n");

     int i;
     for (i = 0; i < iex->psc.len; i++)
          printf("%02x", iex->psc.psc[i]);

     printf("\n");
     printf("ip:               ");

     for (i = 0; i < 16; i++)
          printf("%02x", iex->ip[i]);

     printf("\n");
     printf("port:             %02x%02x\n",
            iex->port[0], iex->port[1]);
     printf("mac               %02x%02x%02x%02x%02x%02x\n",
            iex->mac[0], iex->mac[1], iex->mac[2],
            iex->mac[3], iex->mac[4], iex->mac[5]);
     printf("rcpi_thres:       %d\n", iex->rcpi_thres);
     printf("count_thres:      %d\n", iex->count_thres);
     printf("count_thres_int:  %d\n", iex->count_thres_int);
     printf("edca.ac_be:       %02x%02x%02x%02x\n",
            iex->edca.ac_be[0], iex->edca.ac_be[1],
            iex->edca.ac_be[2], iex->edca.ac_be[3]);
     printf("edca.ac_bk:       %02x%02x%02x%02x\n",
            iex->edca.ac_bk[0], iex->edca.ac_bk[1],
            iex->edca.ac_bk[2], iex->edca.ac_bk[3]);
     printf("edca.ac_vi:       %02x%02x%02x%02x\n",
            iex->edca.ac_vi[0], iex->edca.ac_vi[1],
            iex->edca.ac_vi[2], iex->edca.ac_vi[3]);
     printf("edca.ac_vo:       %02x%02x%02x%02x\n",
            iex->edca.ac_vo[0], iex->edca.ac_vo[1],
            iex->edca.ac_vo[2], iex->edca.ac_vo[3]);
     printf("chan_access:      %d\n", iex->chan_access);
     printf("repeat_rate:      %d\n", iex->repeat_rate);
     printf("loc_2d.latitude:  %02x%02x%02x%02x\n",
            iex->loc_2d.latitude[0], iex->loc_2d.latitude[1],
            iex->loc_2d.latitude[2], iex->loc_2d.latitude[3]);
     printf("loc_2d.longitude: %02x%02x%02x%02x\n",
            iex->loc_2d.longitude[0], iex->loc_2d.longitude[1],
            iex->loc_2d.longitude[2], iex->loc_2d.longitude[3]);
     printf("loc_3d.latitude:  %02x%02x%02x%02x\n",
            iex->loc_3d.latitude[0], iex->loc_3d.latitude[1],
            iex->loc_3d.latitude[2], iex->loc_3d.latitude[3]);
     printf("loc_3d.longitude: %02x%02x%02x%02x\n",
            iex->loc_3d.longitude[0], iex->loc_3d.longitude[1],
            iex->loc_3d.longitude[2], iex->loc_3d.longitude[3]);
     printf("loc_3d.elevation: %02x%02x\n", iex->loc_3d.elevation[0],
            iex->loc_3d.elevation[1]);
     printf("advert_id.len:    %d\n", iex->advert_id.len);

     printf("advert_id.id: ");
     for (i = 0; i < iex->advert_id.len; i++)
          printf("%02x", iex->advert_id.id[i]);

     printf("\n");
     printf("sec_dns:          ");

     for (i = 0; i < 16; i++)
          printf("%02x", iex->sec_dns[i]);

     printf("\n");
     printf("gateway_mac:      %02x%02x%02x%02x%02x%02x\n",
            iex->gateway_mac[0], iex->gateway_mac[1],
            iex->gateway_mac[2], iex->gateway_mac[3],
            iex->gateway_mac[4], iex->gateway_mac[5]);
     printf("\n");
     printf("raw_count:        %d\n", iex->raw_count);
     printf("raw:\n");

     int j;
     for (i = 0; i < iex->raw_count; i++) {
          printf("raw[%d].id:        %d\n", i, iex->raw[i].id);
          printf("raw[%d].len:       %d\n", i, iex->raw[i].len);
          printf("raw[%d].data:\n", i);

          for (j = 0; j < iex->raw[i].len; j++)
               printf("%02x ", iex->raw[i].data[j]);

          printf("\n");
     }

     printf("in_use:\n");
     for (i = 0; i < DSMP_EID_CHANNEL_LOAD+1; i++)
          printf("        (%d, %d)\n", i, iex->use[i]);

     printf("\n-- END IEX--\n");
}

void print_dsm(struct dsmp_dsm *dsm) {
     printf("\n---- fields in dsmp_dsm struct ----\n");
     printf("subtype:   %d\n", dsm->subtype);
     printf("version:   %d\n", dsm->version);
     printf("tpid:      %d\n", dsm->tpid);
     printf("use_n_iex: %d\n", dsm->use_n_iex);

     if (dsm->use_n_iex) {
          printf("n_iex:\n");
          print_iex(dsm->n_iex);
          printf("\n");
     }

     printf("aid:      %08x\n", dsm->aid);
     printf("use_t_iex: %d\n", dsm->use_t_iex);

     if (dsm->use_t_iex) {
          printf("t_iex:\n");
          print_iex(dsm->t_iex);
          printf("\n");
     }

     printf("length:    %d\n", dsm->len);
     printf("data:\n");

     int i;
     for (i = 0; i < dsm->len; i++)
          printf("%02x ", dsm->data[i]);

     printf("\n-- END WSM --\n");
}

void print_sii(struct dsmp_sii *sii) {
     printf("\nBEGIN SII\n");
     printf("aid:       %08x\n", sii->aid);
     printf("chan_index: %d\n", sii->chan_index);
     printf("use_iex:    %d\n", sii->use_iex);

     if (sii->use_iex) {
          printf("iex:\n");
          print_iex(sii->iex);
          printf("\n");
     }

     printf("\nEND SII\n");
}

void print_cii(struct dsmp_cii *cii) {
     printf("\nBEGIN CII\n");
     printf("op_class:  %d\n", cii->op_class);
     printf("chan:      %d\n", cii->chan);
     printf("tx_pow:    %d\n", cii->tx_pow);
     printf("adapt:     %d\n", cii->adapt);
     printf("data_rate: %d\n", cii->data_rate);
     printf("use_iex:   %d\n", cii->use_iex);

     if (cii->use_iex) {
          printf("iex:\n");
          print_iex(cii->iex);
          printf("\n");
     }

     printf("\nEND CII\n");
}

void print_wra(struct dsmp_wra *wra) {
     printf("\nBEGIN WRA\n");
     printf("lifetime:    %02x%02x\n", wra->lifetime[0], wra->lifetime[1]);
     printf("ip_prefix:   ");

     int i;
     for (i = 0; i < 16; i++)
          printf("%02x", wra->ip_prefix[i]);

     printf("\n");
     printf("prefix_len: %d\n", wra->prefix_len);
     printf("gateway:    ");

     for (i = 0; i < 16; i++)
          printf("%02x", wra->gateway[i]);

     printf("\n");
     printf("dns:    ");

     for (i = 0; i < 16; i++)
          printf("%02x", wra->dns[i]);

     printf("\n");
     printf("use_iex:   %d\n", wra->use_iex);

     if (wra->use_iex) {
          printf("iex:\n");
          print_iex(wra->iex);
          printf("\n");
     }

     printf("\nEND WRA\n");
}

void print_dsa(struct dsmp_dsa *dsa) {
     printf("\nBEGIN WSA\n");
     printf("proto version: %d\n", dsa->proto_version);
     printf("WSA Type:      %d\n", dsa->dsaType);
     printf("version:       %d\n", dsa->version);
     printf("id:            %d\n", dsa->id);
     printf("content_count: %d\n", dsa->content_count);
     printf("use_iex:       %d\n", dsa->use_iex);

     if (dsa->use_iex) {
          printf("iex:\n");
          print_iex(dsa->iex);
          printf("\n");
     }

     printf("sii_count:    %d\n", dsa->sii_count);

     int i;

     if (dsa->sii_count > 0) {
          printf("sis:\n");
          for (i = 0; i < dsa->sii_count; i++) {
               printf("sis[%d]:\n", i);
               print_sii(dsa->sis[i]);
               printf("\n");
          }
     }

     printf("cii_count:    %d\n", dsa->cii_count);
     if (dsa->cii_count > 0) {
          printf("cis:\n");
          for (i = 0; i < dsa->cii_count; i++) {
               printf("cis[%d]:\n", i);
               print_cii(dsa->cis[i]);
               printf("\n");
          }
     }

     printf("use_wra      %d\n", dsa->use_wra);
     if (dsa->use_wra) {
          printf("wra:\n");
          print_wra(dsa->wra);
          printf("\n");
     }

     printf("\nEND WSA\n");
}

// print binary format of 1-byte value
void print_bin8(uint8_t value){
    for (int i = 7; i >= 0; i--)
        printf("%d", (value & (1 << i)) >> i );
    printf(",");
}

// print binary format for a given size.
void print_binx(uint8_t *buf, size_t size){
    for (size_t i = 0; i < size; i++){
        print_bin8(*(buf+i));
    }
    printf("\n");
}

struct dsmp_dsm *gen_dsm_metadata(){
     uint8_t subtype = 0, opt_indicator = 1, tpid=0, chat_id=172, data_rate=0x0C;
     int8_t tx_power=0x9E;
     uint32_t aid = 0xC00305;
     uint16_t len = 11;
     uint8_t *data = calloc(11, sizeof(char));
     char *msg = "hello-world";
     if (data==NULL){
          fprintf(stderr, "could not allocate memory\n");
          exit(1);
     }
     memcpy(data, msg, len);
     return create_dsmp_metadata(subtype, tpid, opt_indicator, chat_id, data_rate, tx_power, aid, len, data);
}

enum confirm_result_code gen_dsm_dsmpshortmsg_req(){
     uint8_t info_element_indicator=1, chan_id=172, data_rate=0x0C, chan_load=1, prority = 2;
     int8_t tx_power=0x9E;
     uint64_t dsm_exptime = 1000;
     enum time_slot tmslot = time_slot0;
     uint8_t *peer_macaddr = 0x1166aabbdd22;
     uint32_t aid = 0xC00305;
     uint16_t len = 11;
     uint8_t *data = calloc(len, sizeof(char));
     char *msg = "hello-world";
     if (data==NULL){
          fprintf(stderr, "could not allocate memory\n");
          return rejected_unspecified;
     }
     memcpy(data, msg, len);
     return dsm_dsmpshortmsg_req(chan_id, tmslot, data_rate, tx_power, chan_load, info_element_indicator, 
               prority, dsm_exptime, len, data, peer_macaddr, aid);
}
